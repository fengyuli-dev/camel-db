let hours_worked = 10
