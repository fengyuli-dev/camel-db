parser work distribution + plan finish date

Emerald - parse_where, parse_expression (small syntax tree)
  Finish date - 13th
Yolanda - parse, parse_query, parse_drop, parse_select，parse_from, parse_create
  Finish date - 13th
Chuhan - parse_insert, parse_delete, parse_update

